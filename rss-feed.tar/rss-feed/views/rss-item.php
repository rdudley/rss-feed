<div class="item">
	<div class="title"><h3><a target="_blank" href="<?php echo $link; ?>"><?php echo $title; ?></a></h3></div>
	<div class="pubDate"><?php echo $pubDate; ?></div>
	<div class=description"><?php echo $description; ?></div>
	<div class="link"><a target="_blank" href="<?php echo $link; ?>">Read the full article</a></div>	
</div>
<p>&nbsp;</p>